//My first p5.js project

let x;
let y;

function setup() {
  createCanvas(800,800);
  background(50);
  frameRate(15);
  x = width / 2;
  y = height / 2;
}

function draw() {
  //quando un colore passa sopra ad un altro, rimane impresso su schermo   l'ultimo colore
  stroke(2);
  strokeWeight(1),
  fill(random(255),random(255),random(255));
  rect(x,y,20,20);
  let r = floor(random(4));
  //uso floor per calcolare il valore di "r" più vicino ai numeri interi 1,2,3 e 4 
  //errore di programmazione: dovevo mettere da case 0 a case 3, non case 1 fino a case 4, perchè in questo modo il 4 non veniva mai considerato
  switch (r) {
      case 0:
      x = x + 20;
      break;
      
      case 1:
      x = x - 20;
      break;
      
      case 2:
      y = y + 20;
      break;
      
      //!
      default:
      y = y - 20;
      break;
  }
}

      
    
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
  



